CSDN 博客资源 <br>
1、WebSocket DEMO <br>
    服务器端：SpringBootWebSocketDemo.rar <br>
    客户端：AndroidClientWebSocket.rar<br>
